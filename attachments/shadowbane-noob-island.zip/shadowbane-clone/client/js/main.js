let stickActive = false, stickVec = { x: 0, z: 0 };
let lastMoveSend = 0;
let myId = null, me = null, lastLogs = 0;
let canvas, ctx, cam = { x: 0, z: 0 };
const players = new Map();
const monsters = new Map();
const sprites = {};
const TW = 48, TH = 24;

const NAMES = ["human", "elf", "minotaur", "spider", "snake", "lizard", "orc", "bandit", "beast", "hall", "tree", "fire"];

document.getElementById("joinBtn").onclick = join;

function loadSprites() {
  return Promise.all(NAMES.map(name => new Promise(resolve => {
    const img = new Image();
    img.onload = () => { sprites[name] = img; resolve(); };
    img.onerror = () => resolve();
    img.src = "/sprites/" + name + ".png";
  })));
}

async function join() {
  const username = document.getElementById("username").value.trim() || "Hero";
  const race = document.getElementById("race").value;
  const baseClass = document.getElementById("baseClass").value;
  document.getElementById("status").textContent = "Entering Uthgaard…";
  await loadSprites();
  const res = await fetch("/api/join", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ username, race, baseClass })
  });
  const data = await res.json();
  myId = data.id;
  me = data.player;
  document.getElementById("login").hidden = true;
  document.getElementById("game").hidden = false;
  canvas = document.getElementById("view");
  ctx = canvas.getContext("2d");
  ctx.imageSmoothingEnabled = false;
  resize();
  window.addEventListener("resize", resize);
  setupInput();
  poll();
  requestAnimationFrame(draw);
  window.addEventListener("beforeunload", () => {
    navigator.sendBeacon("/api/leave", new Blob([JSON.stringify({ id: myId })], { type: "application/json" }));
  });
}

function resize() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
  ctx.imageSmoothingEnabled = false;
}

function worldToScreen(x, z) {
  const sx = (x - z) * (TW / 2);
  const sy = (x + z) * (TH / 2);
  return { x: sx + canvas.width / 2 - cam.x, y: sy + canvas.height / 2 - 20 - cam.z };
}

function screenToWorld(sx, sy) {
  const x = sx - canvas.width / 2 + cam.x;
  const y = sy - canvas.height / 2 + 20 + cam.z;
  const wx = (x / (TW / 2) + y / (TH / 2)) / 2;
  const wz = (y / (TH / 2) - x / (TW / 2)) / 2;
  return { x: wx, z: wz };
}

async function poll() {
  if (!myId) return;
  try {
    const state = await (await fetch("/api/state")).json();
    players.clear();
    state.players.forEach(p => {
      players.set(p.id, p);
      if (p.id === myId) me = p;
    });
    monsters.clear();
    state.monsters.forEach(m => monsters.set(m.id, m));
    if (me) {
      document.getElementById("stats").innerHTML =
        `<b>${me.username}</b> ${me.race} ${me.prestigeClass || me.baseClass} · Lv ${me.level} · Gold ${me.gold}` +
        `<div class="bar hp"><i style="width:${Math.max(0, me.hp / me.maxHp * 100)}%"></i><span>HP ${Math.round(me.hp)}/${me.maxHp}</span></div>` +
        `<div class="bar mp"><i style="width:${Math.max(0, me.mana / me.maxMana * 100)}%"></i><span>MP ${Math.round(me.mana)}/${me.maxMana}</span></div>`;
      document.getElementById("promoteBtn").hidden = !(me.level >= 10 && !me.prestigeClass);
    }
    if (state.logs && state.logs.length !== lastLogs) {
      const box = document.getElementById("messages");
      box.innerHTML = state.logs.map(l => `<div>${l}</div>`).join("");
      box.scrollTop = box.scrollHeight;
      lastLogs = state.logs.length;
    }
  } catch (e) {}
  setTimeout(poll, 180);
}

const TREES = [[-7, 3], [-9, -2], [5, -7], [9, 3], [-3, 9], [11, -3], [-11, 7], [7, 9], [-13, -5], [13, 7], [2, -9], [-6, -8], [15, 1], [-15, 2]];
const FIRES = [[3.2, 2.4], [-2.6, 3.1]];
const HUTS = [[0, 0], [5.5, -1.2]];

function tileColor(x, z) {
  const d = Math.hypot(x, z);
  if (d > 16) return ((x + z) & 1) ? "#1a3330" : "#16302c";
  if (d < 4.2) return ((x * 3 + z) % 5 === 0) ? "#6d5a3e" : "#7a6546";
  if (Math.abs(x) < 1.2 || Math.abs(z) < 1.2) return "#6a563c";
  const camps = [[11, 6], [-8, 8], [16, -9], [-14, -11], [19, 14], [-18, 17]];
  for (const c of camps) if (Math.hypot(x - c[0], z - c[1]) < 2.2) return "#5a4032";
  const n = (Math.abs(x * 13 + z * 7) % 5);
  return n === 0 ? "#3e5a34" : n === 1 ? "#46683c" : "#35522e";
}

function drawDiamond(x, z, fill) {
  const p = worldToScreen(x, z);
  ctx.beginPath();
  ctx.moveTo(p.x, p.y - TH / 2);
  ctx.lineTo(p.x + TW / 2, p.y);
  ctx.lineTo(p.x, p.y + TH / 2);
  ctx.lineTo(p.x - TW / 2, p.y);
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
}

function shadowAt(x, z, w) {
  const p = worldToScreen(x, z);
  ctx.save();
  ctx.translate(p.x, p.y + 4);
  ctx.scale(1, 0.4);
  ctx.beginPath();
  ctx.arc(0, 0, w, 0, Math.PI * 2);
  ctx.fillStyle = "rgba(0,0,0,.35)";
  ctx.fill();
  ctx.restore();
}

function drawSprite(name, x, z, scale) {
  const img = sprites[name];
  const p = worldToScreen(x, z);
  if (!img) return;
  const w = img.width * scale;
  const h = img.height * scale;
  ctx.imageSmoothingEnabled = false;
  ctx.drawImage(img, p.x - w / 2, p.y - h + 10, w, h);
}

function draw() {
  requestAnimationFrame(draw);
  if (!ctx) return;
  stickStep();
  if (me) {
    const tx = (me.x - me.z) * (TW / 2);
    const tz = (me.x + me.z) * (TH / 2);
    cam.x += (tx - cam.x) * 0.15;
    cam.z += (tz - cam.z) * 0.15;
  }
  ctx.fillStyle = "#10241f";
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  for (let x = -18; x <= 18; x++) {
    for (let z = -18; z <= 18; z++) drawDiamond(x, z, tileColor(x, z));
  }

  const drawables = [];
  HUTS.forEach(([x, z], i) => drawables.push({ kind: "s", name: "hall", x, z, scale: i ? 0.34 : 0.42, key: x + z }));
  TREES.forEach(([x, z]) => drawables.push({ kind: "s", name: "tree", x, z, scale: 0.28, key: x + z }));
  FIRES.forEach(([x, z]) => drawables.push({ kind: "s", name: "fire", x, z, scale: 0.16, key: x + z + 0.1 }));
  monsters.forEach(m => { if (m.hp > 0) drawables.push({ kind: "m", e: m, key: m.x + m.z }); });
  players.forEach(p => { if (p.hp > 0) drawables.push({ kind: "p", e: p, key: p.x + p.z }); });
  drawables.sort((a, b) => a.key - b.key);
  drawables.forEach(d => {
    if (d.kind === "s") {
      shadowAt(d.x, d.z, d.name === "tree" ? 22 : 16);
      drawSprite(d.name, d.x, d.z, d.scale);
    } else if (d.kind === "m") {
      shadowAt(d.e.x, d.e.z, 14);
      drawSprite(d.e.type.toLowerCase(), d.e.x, d.e.z, 0.18);
      const p = worldToScreen(d.e.x, d.e.z);
      ctx.fillStyle = "#200";
      ctx.fillRect(p.x - 16, p.y - 58, 32, 4);
      ctx.fillStyle = "#a33";
      ctx.fillRect(p.x - 16, p.y - 58, 32 * (d.e.hp / d.e.maxHp), 4);
    } else {
      const race = (d.e.race || "human").toLowerCase();
      shadowAt(d.e.x, d.e.z, 14);
      drawSprite(race, d.e.x, d.e.z, race === "minotaur" ? 0.2 : 0.18);
      const p = worldToScreen(d.e.x, d.e.z);
      ctx.fillStyle = d.e.id === myId ? "#f0e2b0" : "#ddd";
      ctx.font = "13px Georgia";
      ctx.textAlign = "center";
      ctx.fillText(d.e.username, p.x, p.y - 92);
    }
  });

  const g = ctx.createRadialGradient(canvas.width / 2, canvas.height / 2, canvas.height * 0.3, canvas.width / 2, canvas.height / 2, canvas.height * 0.72);
  g.addColorStop(0, "rgba(0,0,0,0)");
  g.addColorStop(1, "rgba(6,10,8,.55)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, canvas.width, canvas.height);
}

const MAP_CAMPS = [
  { name: "Spiders", level: 2, x: 22, z: 12, color: "#6a3030" },
  { name: "Snakes", level: 4, x: -16, z: 16, color: "#2f6a38" },
  { name: "Lizards", level: 8, x: 32, z: -18, color: "#6a6a30" },
  { name: "Orcs", level: 13, x: -28, z: -22, color: "#6a4a28" },
  { name: "Bandits", level: 18, x: 38, z: 28, color: "#4a306a" },
  { name: "Beasts", level: 23, x: -36, z: 34, color: "#6a3060" }
];

function openMap() {
  document.getElementById("mapOverlay").hidden = false;
  drawWorldMap();
}

function drawWorldMap() {
  const c = document.getElementById("mapCanvas");
  const g = c.getContext("2d");
  const w = c.width, h = c.height;
  g.clearRect(0, 0, w, h);
  g.fillStyle = "#0e1c18";
  g.fillRect(0, 0, w, h);
  const span = 92;
  const to = (x, z) => ({ x: w / 2 + (x / span) * w, y: h / 2 + (z / span) * h });
  g.fillStyle = "#2a4630";
  g.beginPath();
  g.ellipse(w / 2, h / 2, w * 0.42, h * 0.42, 0, 0, Math.PI * 2);
  g.fill();
  g.strokeStyle = "#8a7344";
  g.stroke();
  g.fillStyle = "#6a563c";
  const hall = to(0, 0);
  g.fillRect(hall.x - 8, hall.y - 8, 16, 16);
  g.fillStyle = "#f0e2b0";
  g.font = "14px Georgia";
  g.textAlign = "center";
  g.fillText("Uthgaard Hamlet", hall.x, hall.y - 14);
  MAP_CAMPS.forEach(camp => {
    const p = to(camp.x, camp.z);
    g.fillStyle = camp.color;
    g.beginPath();
    g.arc(p.x, p.y, 8, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = "#efe6c8";
    g.font = "13px Georgia";
    g.fillText(camp.name + "  " + camp.level, p.x, p.y - 12);
  });
  players.forEach(p => {
    if (p.hp <= 0) return;
    const pt = to(p.x, p.z);
    g.fillStyle = p.id === myId ? "#f2d36b" : "#d8d8d8";
    g.beginPath();
    g.arc(pt.x, pt.y, 5, 0, Math.PI * 2);
    g.fill();
    g.fillText(p.username, pt.x, pt.y + 16);
  });
  g.fillStyle = "#cbb";
  g.font = "12px Georgia";
  g.fillText("You are the gold mark. Camps ring the hamlet, levels 2–23.", w / 2, h - 16);
}

function setupInput() {
  canvas.addEventListener("pointerdown", e => {
    if (!me || me.hp <= 0) return;
    const w = screenToWorld(e.clientX, e.clientY);
    const rot = Math.atan2(w.x - me.x, w.z - me.z);
    fetch("/api/move", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id: myId, x: w.x, z: w.z, rotation: rot })
    });
  });
  document.querySelectorAll("#skills button[data-skill]").forEach(btn => {
    btn.addEventListener("pointerup", e => { e.preventDefault(); act(btn.dataset.skill); });
  });
  document.getElementById("promoteBtn").addEventListener("pointerup", e => {
    e.preventDefault();
    const map = { Fighter: "Warrior", Healer: "Priest", Mage: "Wizard", Rogue: "Scout" };
    const cls = map[me.baseClass];
    if (confirm("Promote to " + cls + "?")) {
      fetch("/api/promote", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: myId, cls }) });
    }
  });
  document.getElementById("chatToggle").addEventListener("pointerup", e => {
    e.preventDefault();
    document.getElementById("chat").classList.toggle("open");
  });
  document.getElementById("mapBtn").addEventListener("pointerup", e => {
    e.preventDefault();
    e.stopPropagation();
    openMap();
  });
  document.getElementById("mapClose").addEventListener("pointerup", e => {
    e.preventDefault();
    document.getElementById("mapOverlay").hidden = true;
  });
  document.getElementById("chatInput").addEventListener("keydown", e => {
    if (e.key === "Enter" && e.target.value.trim()) {
      fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ id: myId, msg: e.target.value.trim() }) });
      e.target.value = "";
    }
  });
  setupStick();
}

function setupStick() {
  const stick = document.getElementById("stick");
  const knob = document.getElementById("knob");
  function set(clientX, clientY) {
    const r = stick.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    let dx = clientX - cx, dy = clientY - cy;
    const max = r.width / 2 - 8;
    const len = Math.hypot(dx, dy) || 1;
    const scale = Math.min(1, max / len);
    dx *= scale; dy *= scale;
    knob.style.left = (r.width / 2 - 20 + dx) + "px";
    knob.style.top = (r.height / 2 - 20 + dy) + "px";
    stickVec.x = dx / max;
    stickVec.z = dy / max;
  }
  function reset() {
    stickActive = false;
    stickVec.x = 0; stickVec.z = 0;
    knob.style.left = "35px";
    knob.style.top = "35px";
  }
  stick.addEventListener("pointerdown", e => { stick.setPointerCapture(e.pointerId); stickActive = true; set(e.clientX, e.clientY); });
  stick.addEventListener("pointermove", e => { if (stickActive) set(e.clientX, e.clientY); });
  stick.addEventListener("pointerup", reset);
  stick.addEventListener("pointercancel", reset);
}

function stickStep() {
  if (!stickActive || !me || me.hp <= 0) return;
  const now = performance.now();
  if (now - lastMoveSend < 120) return;
  lastMoveSend = now;
  const speed = 1.6;
  const x = me.x + stickVec.x * speed;
  const z = me.z + stickVec.z * speed;
  fetch("/api/move", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id: myId, x, z, rotation: Math.atan2(stickVec.x, stickVec.z) })
  });
}

function nearestMonster() {
  if (!me) return null;
  let id = null, best = 6;
  monsters.forEach(m => {
    if (m.hp <= 0) return;
    const d = Math.hypot(m.x - me.x, m.z - me.z);
    if (d < best) { best = d; id = m.id; }
  });
  return id;
}

function act(skill) {
  const targetId = nearestMonster();
  const path = skill === "attack" ? "/api/attack" : "/api/skill";
  fetch(path, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id: myId, skill, targetId })
  });
}
