# Uthgaard — Shadowbane Noob Island prototype

Browser multiplayer slice of the 2003 Shadowbane starter island. Isometric Three.js client, one hamlet, six monster camps, levels 1–25.

Races: Human, Elf, Minotaur.
Paths: Fighter → Warrior, Healer → Priest, Mage → Wizard, Rogue → Scout (promote at 10).

## Run

```bash
cd shadowbane-clone
node server/index.js
```

Open http://localhost:2567

No npm install. Node 18+ only. Character progress is saved by username in `data/characters.json` when you leave the page.

## Play

- Click the ground to walk.
- Attack / Fireball / Stab hit the nearest living creature within range.
- Heal is for Healers and Priests. Fireball for Mages and Wizards. Stab for Rogues and Scouts.
- Camps get harder as you leave the hamlet: spiders, snakes, lizards, orcs, bandits, beasts.
- Open a second tab with a different name to see the other player.
