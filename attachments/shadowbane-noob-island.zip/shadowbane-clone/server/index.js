const http = require("http");
const fs = require("fs");
const path = require("path");

const PORT = process.env.PORT || 2567;
const ROOT = path.join(__dirname, "..");
const DATA = path.join(ROOT, "data", "characters.json");

function loadChars() {
  try { return JSON.parse(fs.readFileSync(DATA, "utf8")); } catch { return {}; }
}
function saveChars(data) {
  fs.mkdirSync(path.dirname(DATA), { recursive: true });
  fs.writeFileSync(DATA, JSON.stringify(data, null, 2));
}

const characters = loadChars();
const players = new Map();
const monsters = new Map();
let mid = 1;

const CAMPS = [
  { type: "Spider", level: 2, count: 6, cx: 22, cz: 12 },
  { type: "Snake", level: 4, count: 5, cx: -16, cz: 16 },
  { type: "Lizard", level: 8, count: 4, cx: 32, cz: -18 },
  { type: "Orc", level: 13, count: 4, cx: -28, cz: -22 },
  { type: "Bandit", level: 18, count: 3, cx: 38, cz: 28 },
  { type: "Beast", level: 23, count: 3, cx: -36, cz: 34 }
];

function spawnCamp(camp) {
  for (let i = 0; i < camp.count; i++) {
    const id = "m" + mid++;
    const hp = 36 + camp.level * 11;
    monsters.set(id, {
      id, type: camp.type, level: camp.level,
      maxHp: hp, hp,
      x: camp.cx + (Math.random() - 0.5) * 8,
      z: camp.cz + (Math.random() - 0.5) * 8,
      homeX: camp.cx, homeZ: camp.cz,
      targetId: null, respawnAt: 0
    });
  }
}
CAMPS.forEach(spawnCamp);

function applyStats(p) {
  let con = 30, intel = 30;
  if (p.race === "Elf") { intel += 12; con -= 4; }
  if (p.race === "Minotaur") { con += 16; intel -= 8; }
  if (p.baseClass === "Fighter") con += 6;
  if (p.baseClass === "Mage") intel += 10;
  if (p.baseClass === "Healer") intel += 6;
  if (p.baseClass === "Rogue") con += 2;
  p.maxHp = Math.floor(70 + con * 2 + p.level * 9);
  p.maxMana = Math.floor(24 + intel * 2 + p.level * 4);
  if (p.prestigeClass === "Warrior") p.maxHp += 45;
  if (p.prestigeClass === "Wizard") p.maxMana += 35;
  if (p.prestigeClass === "Priest") p.maxMana += 20;
  if (p.prestigeClass === "Scout") p.maxHp += 18;
  if (p.hp == null || p.hp > p.maxHp) p.hp = p.maxHp;
  if (p.mana == null || p.mana > p.maxMana) p.mana = p.maxMana;
}

function xpNeed(level) { return level * 70; }

function levelUp(p) {
  while (p.xp >= xpNeed(p.level) && p.level < 25) {
    p.xp -= xpNeed(p.level);
    p.level++;
    applyStats(p);
    p.hp = p.maxHp;
    p.mana = p.maxMana;
  }
}

function publicState() {
  return {
    players: [...players.values()].map(p => ({
      id: p.id, username: p.username, race: p.race,
      baseClass: p.baseClass, prestigeClass: p.prestigeClass,
      level: p.level, xp: p.xp, gold: p.gold,
      hp: p.hp, maxHp: p.maxHp, mana: p.mana, maxMana: p.maxMana,
      x: p.x, z: p.z, rotation: p.rotation
    })),
    monsters: [...monsters.values()].map(m => ({
      id: m.id, type: m.type, level: m.level,
      hp: m.hp, maxHp: m.maxHp, x: m.x, z: m.z
    }))
  };
}

const logs = [];
function log(msg) {
  logs.push(msg);
  if (logs.length > 40) logs.shift();
}

setInterval(() => {
  const now = Date.now();
  for (const m of monsters.values()) {
    if (m.hp <= 0) {
      if (m.respawnAt && now > m.respawnAt) {
        m.hp = m.maxHp;
        m.x = m.homeX + (Math.random() - 0.5) * 6;
        m.z = m.homeZ + (Math.random() - 0.5) * 6;
        m.targetId = null;
        m.respawnAt = 0;
      }
      continue;
    }
    if (!m.targetId) {
      for (const p of players.values()) {
        if (p.hp > 0 && Math.hypot(p.x - m.x, p.z - m.z) < 6.5) {
          m.targetId = p.id;
          break;
        }
      }
    }
    if (m.targetId) {
      const t = players.get(m.targetId);
      if (!t || t.hp <= 0) { m.targetId = null; continue; }
      const d = Math.hypot(t.x - m.x, t.z - m.z);
      if (d < 2.2) {
        if (Math.random() < 0.35) {
          t.hp = Math.max(0, t.hp - (3 + Math.floor(m.level * 0.7)));
          if (t.hp <= 0) {
            log(`${t.username} was slain by a ${m.type}.`);
            t.x = 0; t.z = 0; t.hp = t.maxHp;
            t.xp = Math.floor(t.xp * 0.95);
            m.targetId = null;
          }
        }
      } else if (d < 18) {
        m.x += ((t.x - m.x) / d) * 0.55;
        m.z += ((t.z - m.z) / d) * 0.55;
      } else m.targetId = null;
    }
  }
  for (const p of players.values()) {
    if (p.hp > 0 && p.hp < p.maxHp) p.hp = Math.min(p.maxHp, p.hp + 0.4);
    if (p.mana < p.maxMana) p.mana = Math.min(p.maxMana, p.mana + 0.6);
  }
}, 400);

function readBody(req) {
  return new Promise((resolve) => {
    let b = "";
    req.on("data", c => b += c);
    req.on("end", () => {
      try { resolve(b ? JSON.parse(b) : {}); } catch { resolve({}); }
    });
  });
}

function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { "Content-Type": "application/json", "Access-Control-Allow-Origin": "*" });
  res.end(body);
}

function mime(file) {
  if (file.endsWith(".html")) return "text/html";
  if (file.endsWith(".js")) return "text/javascript";
  if (file.endsWith(".css")) return "text/css";
  return "application/octet-stream";
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, "http://localhost");

  if (req.method === "OPTIONS") {
    res.writeHead(204, { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "Content-Type" });
    return res.end();
  }

  if (url.pathname === "/api/state") return send(res, 200, { ...publicState(), logs });

  if (url.pathname === "/api/join" && req.method === "POST") {
    const data = await readBody(req);
    const username = String(data.username || "Hero").slice(0, 16);
    const saved = characters[username] || {};
    const id = "p" + Math.random().toString(36).slice(2, 10);
    const player = {
      id, username,
      race: data.race || saved.race || "Human",
      baseClass: data.baseClass || saved.baseClass || "Fighter",
      prestigeClass: saved.prestigeClass || "",
      level: saved.level || 1,
      xp: saved.xp || 0,
      gold: saved.gold || 40,
      x: 0, z: 0, rotation: 0,
      hp: null, mana: null, maxHp: 100, maxMana: 50
    };
    applyStats(player);
    player.hp = player.maxHp;
    player.mana = player.maxMana;
    players.set(id, player);
    log(`${player.username} entered the Hamlet of Uthgaard.`);
    return send(res, 200, { id, player });
  }

  if (url.pathname === "/api/leave" && req.method === "POST") {
    const data = await readBody(req);
    const p = players.get(data.id);
    if (p) {
      characters[p.username] = { ...p };
      saveChars(characters);
      players.delete(data.id);
      log(`${p.username} left the island.`);
    }
    return send(res, 200, { ok: true });
  }

  if (url.pathname === "/api/move" && req.method === "POST") {
    const data = await readBody(req);
    const p = players.get(data.id);
    if (p && p.hp > 0) {
      p.x = Math.max(-38, Math.min(38, Number(data.x) || 0));
      p.z = Math.max(-38, Math.min(38, Number(data.z) || 0));
      p.rotation = Number(data.rotation) || 0;
    }
    return send(res, 200, { ok: true });
  }

  if (url.pathname === "/api/attack" && req.method === "POST") {
    const data = await readBody(req);
    const p = players.get(data.id);
    const m = monsters.get(data.targetId);
    if (!p || p.hp <= 0 || !m || m.hp <= 0) return send(res, 200, { ok: false });
    if (Math.hypot(p.x - m.x, p.z - m.z) > 4.5) return send(res, 200, { ok: false, reason: "too far" });
    const bonus = (p.baseClass === "Fighter" || p.prestigeClass === "Warrior") ? 5 : 0;
    const dmg = 7 + p.level * 2 + bonus;
    m.hp = Math.max(0, m.hp - dmg);
    m.targetId = p.id;
    if (m.hp <= 0) {
      const xp = 8 + m.level * 5;
      p.xp += xp;
      p.gold += 1 + Math.floor(m.level / 2);
      const before = p.level;
      levelUp(p);
      m.respawnAt = Date.now() + 8000;
      log(`${p.username} slew a ${m.type} (+${xp} XP)${p.level > before ? ` and reached level ${p.level}` : ""}.`);
    }
    return send(res, 200, { ok: true, dmg });
  }

  if (url.pathname === "/api/skill" && req.method === "POST") {
    const data = await readBody(req);
    const p = players.get(data.id);
    if (!p || p.hp <= 0 || p.mana < 10) return send(res, 200, { ok: false });
    if (data.skill === "heal" && (p.baseClass === "Healer" || p.prestigeClass === "Priest")) {
      p.mana -= 10;
      p.hp = Math.min(p.maxHp, p.hp + 28 + p.level * 2);
      return send(res, 200, { ok: true });
    }
    if (data.skill === "fireball" && (p.baseClass === "Mage" || p.prestigeClass === "Wizard")) {
      const m = monsters.get(data.targetId);
      if (!m || m.hp <= 0) return send(res, 200, { ok: false });
      p.mana -= 10;
      m.hp = Math.max(0, m.hp - (14 + p.level * 3));
      m.targetId = p.id;
      if (m.hp <= 0) {
        p.xp += 8 + m.level * 5;
        p.gold += 2;
        levelUp(p);
        m.respawnAt = Date.now() + 8000;
        log(`${p.username}'s fireball destroyed a ${m.type}.`);
      }
      return send(res, 200, { ok: true });
    }
    if (data.skill === "stab" && (p.baseClass === "Rogue" || p.prestigeClass === "Scout")) {
      const m = monsters.get(data.targetId);
      if (!m || m.hp <= 0) return send(res, 200, { ok: false });
      p.mana -= 8;
      m.hp = Math.max(0, m.hp - (12 + p.level * 2));
      m.targetId = p.id;
      if (m.hp <= 0) {
        p.xp += 8 + m.level * 5;
        levelUp(p);
        m.respawnAt = Date.now() + 8000;
      }
      return send(res, 200, { ok: true });
    }
    return send(res, 200, { ok: false, reason: "class cannot use that" });
  }

  if (url.pathname === "/api/promote" && req.method === "POST") {
    const data = await readBody(req);
    const p = players.get(data.id);
    const allowed = { Fighter: ["Warrior"], Healer: ["Priest"], Mage: ["Wizard"], Rogue: ["Scout"] };
    if (!p || p.level < 10 || p.prestigeClass) return send(res, 200, { ok: false });
    if (!(allowed[p.baseClass] || []).includes(data.cls)) return send(res, 200, { ok: false });
    p.prestigeClass = data.cls;
    applyStats(p);
    log(`${p.username} promoted to ${data.cls}.`);
    return send(res, 200, { ok: true });
  }

  if (url.pathname === "/api/chat" && req.method === "POST") {
    const data = await readBody(req);
    const p = players.get(data.id);
    if (p && data.msg) log(`${p.username}: ${String(data.msg).slice(0, 120)}`);
    return send(res, 200, { ok: true });
  }

  let file = url.pathname === "/" ? "/client/index.html" : url.pathname;
  if (!file.startsWith("/client/")) file = "/client" + file;
  const abs = path.normalize(path.join(ROOT, file));
  if (!abs.startsWith(ROOT)) { res.writeHead(403); return res.end("no"); }
  fs.readFile(abs, (err, buf) => {
    if (err) { res.writeHead(404); return res.end("not found"); }
    res.writeHead(200, { "Content-Type": mime(abs) });
    res.end(buf);
  });
});

server.listen(PORT, () => {
  console.log("Uthgaard listening on http://localhost:" + PORT);
});
